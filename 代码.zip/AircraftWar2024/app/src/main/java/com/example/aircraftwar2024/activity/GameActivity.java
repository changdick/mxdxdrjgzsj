package com.example.aircraftwar2024.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.PrintWriterPrinter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.aircraftwar2024.game.BaseGame;
import com.example.aircraftwar2024.game.EasyGame;
import com.example.aircraftwar2024.game.HardGame;
import com.example.aircraftwar2024.game.MediumGame;
import com.example.aircraftwar2024.music.MyMediaPlayer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;


public class GameActivity extends AppCompatActivity {
    private static final String TAG = "GameActivity";

    private int gameType=0;
    public static int screenWidth,screenHeight;
    public static boolean musicSwitch;


    public static Handler handler ;


    private Socket socket;
    private PrintWriter writer;
    private BufferedReader reader;
    private static int opponentScore = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 如果选单机模式，会运行以下内容
        super.onCreate(savedInstanceState);
        getScreenHW();


            ActivityManager.getActivityManager().finishActivity();

            ActivityManager.getActivityManager().addActivity(this);


            handler = new Handler(Looper.getMainLooper()) {
                @Override
                public void handleMessage(Message msg) {
                    super.handleMessage(msg);
                    Log.d(TAG, "HandleMessage");
                    if (msg.what == 1) {
                        // 1 做页面跳转，跳转到排行榜界面
                        Intent intent = new Intent(GameActivity.this, RecordActivity.class);

                        //参数没传，用户数据没给
                        intent.putExtra("gameType", gameType);   // 把游戏难度传到record界面
                        intent.putExtra("score", msg.arg1);
                        startActivity(intent);

                    }
                }
            };



            if (getIntent() != null) {
                gameType = getIntent().getIntExtra("gameType", 1);
                musicSwitch = getIntent().getBooleanExtra("musicSwitch", true);
            }

            /*TODO:根据用户选择的难度加载相应的游戏界面*/
            BaseGame baseGameView = null;

            if (gameType == 1) {
                baseGameView = new EasyGame(this, handler);

            } else if (gameType == 2) {
                baseGameView = new MediumGame(this, handler);

            } else {
                baseGameView = new HardGame(this, handler);
            }


            setContentView(baseGameView);





    }


    public void getScreenHW(){
        //定义DisplayMetrics 对象
        DisplayMetrics dm = new DisplayMetrics();
        //取得窗口属性
        getDisplay().getRealMetrics(dm);

        //窗口的宽度
        screenWidth= dm.widthPixels;
        //窗口高度
        screenHeight = dm.heightPixels;

        Log.i(TAG, "screenWidth : " + screenWidth + " screenHeight : " + screenHeight);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }


}