package com.example.aircraftwar2024.activity;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.aircraftwar2024.R;
import com.example.aircraftwar2024.game.BaseGame;
import com.example.aircraftwar2024.game.EasyGame;
import com.example.aircraftwar2024.game.HardGame;
import com.example.aircraftwar2024.game.MediumGame;
import com.example.aircraftwar2024.music.MyMediaPlayer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.SortedMap;


/**
 * 220110430
 * 进入后直接把界面设置成MainActivity的界面并创建一个AlertDiaglog，从而实现点击”联机对战“后跳出AlertDiaglog的功能。
 * 剩下的逻辑是启动一个有handler的CLientThread子线程。而PVPActivity要做什么，全在handler中定义。
 * ClientThread先连接服务器，之后不会向服务器发送消息，而是被动等待服务器通知开始游戏(服务器会自行判断是否两个客户端连接上，然后主动通知)。
 * 收到服务器消息后，ClientThread子线程里直接把服务器发来的内容作为message的obj字段，用handler发message上来主线程(代码逻辑在ClientThread类)。主线程收message后处理（有逻辑判断）
 * Basegame的创建启动、发送分数、告知服务器游戏结束，全部是handler收消息的处理内容，(代码全在定义handler的时候)。主线程创建一个Basegame是handler收到开始信号的处理内容。
 * handler收到开始信号的处理的内容为：创建并开始Basegame类。从创建了之后，循环从游戏线程获取到分数（getScore方法），并且发服务器。（也是为什么Socket以及Socket提供的writer和reader均为PVPActivity的类的属性，在ClientThread中创建他们，但是writer的使用是在主线程的handler的处理内容中）
 * 一旦英雄死亡，游戏子线程会提供游戏结束的flag，（Basegame类里的gameOverFlag信号），这个信号用于判断发送分数的循环应该结束，并且结束后向服务器发end信号。
 * 并且立即做一个画面切换，切成endpage，此处为了在endpage中更新对手分数，有一个注意点。
 * 这个注意点是：
 * 要获取到endpage中两个TextView，那就必须作为类的属性声明他们，因为不是在同一个地方调用。
 * 只有在 setContentView()调用，把界面设置成了endpage后，才能够用findById方法获取这两个textview，否则报错，Stack Overflow上面查的
 * 什么时候用setText更新分数，自机得分可以获取到textview时候立刻设置，但是对手得分需要反复更新，如果在RunOnUIThread那个代码块里面用循环设置的话也报错，因为他是接收到服务器发来的内容(除了特定内容肯定是分数)的时候，
 * 会把内容设置为opponentScore属性，那么可以在更新完opponentScore的同时去做setText，从而更新对手的分数
 * 但是注意（调试了很久）这边判断游戏结束，必须在PVPActivity里面设置一个游戏结束的标志信号，heroNotValid，不能用游戏线程里面的gameOverFlag,经过思考，
 * 原因可能是因为：在进行判断的时候，gameOverFlag已经为True，但是setContentView(R.layout.endpage)这一句还没有执行，如果这句没有执行，那么想要设置的Textview此时还是null，就会发生错误。
 * 解决方法：加了个PVPActivity的属性，标志信号heroNotValid用于结束界面更新对手分数使用，并且在setContentView执行后才把它设置为true，就不会再遇到Textview要设置时候还是null的情况。
 *
 * 服务器会自行判断何时通知双方结束游戏，一旦服务器通知了结束游戏，就会做活动跳转
 */
public class PVPActivity extends AppCompatActivity {
    private static final String TAG = "PVPActivity";

    public static int screenWidth,screenHeight;
    public static boolean musicSwitch;  // 实验6更新了音乐开关的逻辑后现在不需要这个

    /**
     * 连接到服务器的Socket，以及Socket提供的读写接口
     */
    private PrintWriter writer;
    private Socket socket;
    private BufferedReader reader;

    BaseGame game;
    Handler handler ;
    /**
     * 对手分数，有一个对应的get方法，在Basegame中绘制的地方调用
     */
    private static int opponentScore;

    /**
     * 切换到endPage界面后，显示自机和对手分数，且对手分数是需要实时更新，两个TextVi控件
     */
    TextView yourScore ;
    TextView oppoScore ;
    /**
     * 为了实现上一活动MainActivity中点击“联机对战”后原地弹出AlertDiaglog，就在此活动中，进入活动立即会创建的AlertDialog
     */
    AlertDialog alertDialog;

    boolean heroNotValid;        // 这边在ＰＶＰＡｃｔｉｖｉｔｙ里面加入一个heroNotValid用于标记游戏结束，而不是用本来的basegame里面的gameoverflag，因为一旦英雄级坠毁，gameoverflag立即为true（这是子线程里的），但是PVPActivity未必来得及通知服务器
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 进入该Activity后，将该Activity加入到ActivityManager中，上一个活动是MainActivity，不需要结束掉。
        ActivityManager.getActivityManager().addActivity(this);

        getScreenHW();
        super.onCreate(savedInstanceState);

        // 下面这些代码是进入该活动后立即把界面设置成MainActivity的界面并创建一个AlertDiaglog，从而实现点击”联机对战“后跳出AlertDiaglog的功能。
        setContentView(R.layout.activity_main); //先设置成上个界面
        // 在上个界面的基础上直接放dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("匹配中，请等待……");
        builder.setCancelable(false);
        alertDialog = builder.create();
        alertDialog.show();


        Log.i(TAG, "get to PVPACtivity");  // 发一个Log，供调试参考

        /*
             逆天大bug，调惨了！
             最早误以为这个handleMessage（因为handler只用到了和服务器通信子线程的交流中）误以为msg.what的判断是不必要的，实际上是必要的，msg.what必须设置成不是1的值！！
             原因在于game里面也读入handler，并且game本身会向上面的主线程传message，所以这个handler同时属于game和clientThread，game在游戏结束的时刻用handler传了一个msg.what为1的消息，传出了分数
             那是之前实验写好的，现在虽然联机模式的实现不是用game传消息出来，而是主线程主动获取game.gameOverFlag去判断游戏是否结束，主线程的需求是不需要获得game发出来的消息的。但是实际上game会发消息出来
             handler收到game发的消息之后，game的消息what就是1，并且game发的消息obj是null，所以出bug

             实际上这个handler在同时处理两个子线程的通信，它们确实可以这么做，这时候what就用来区分是哪一个子线程发的message，game发的标1，clientThread发的标2,handler处理的时候必须判断what为2，才知道是通信子线程的，进行处理
             what为1的不管。

         */
        // 子线程收到服务器发来的消息后，发送出来并处理的handler
        handler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                // handler肯定会收到消息，一共有三种消息："start"、"gameover"和分数的数字的字符串
                // 第一种是start，收到后应关闭AlertDiaglog，开启游戏线程
                if(msg.what == 2 && msg.obj.equals("start")) {
                    game = new MediumGame(PVPActivity.this, this);    // 这是handler里面的方法里，所以这里直接用this指的是handler对象
                    alertDialog.dismiss();
                    setContentView(game);  // 设置界面

                    // 开始游戏后，就应该立即创建并启动发送分数的线程
                    new Thread(()->{
                        // 发送分数
                        while(!game.gameOverFlag) {
                            writer.println(game.getScore());  // 发送分数
                            Log.i(TAG, "send score to Server");

                            try {
                                Thread.sleep(50);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }

                        }
                        // 死亡后应该发送死亡信号
                        writer.println("end");
                        Log.i(TAG, "send end signal to Server");
                        // 切成得分页面
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
//                               切换到endPage，即己方坠毁而对手仍在游戏，会实时更新对手分数
                                setContentView(R.layout.endpage); // 先切排行榜试试
//                                 这两句必须放在 setContentView后面
                                yourScore = findViewById(R.id.textYourScore2);
                                oppoScore = findViewById(R.id.textOppoScore2);
                                yourScore.setText(String.valueOf(game.getScore()));
                                heroNotValid = true; //在这个时候设置heroNotValid标志
                            }
                        });
                    }).start();
                } else if (msg.what == 2 && msg.obj.equals("gameover")) {
                    Intent intent = new Intent(PVPActivity.this, PVPOverActivity.class);
                    intent.putExtra("yourScore", game.getScore());
                    intent.putExtra("oppoScore", opponentScore);
                    startActivity(intent);
                } else {
                    // 除了开始和结束用到上面的if块，其他时候都在这里，肯定收到对方的分数，传给game去显示
                    if((String)msg.obj != null) {
                        opponentScore = Integer.parseInt((String)msg.obj);
                        if(heroNotValid)       // 这一个不可以使用game.gameOverFlag来判断！！
                            oppoScore.setText(String.valueOf(opponentScore));
                    }
                }
            }
        };
        // 开启线程
        new Thread(new ClientThread(handler)).start();
    }

    public void getScreenHW(){
        //定义DisplayMetrics 对象
        DisplayMetrics dm = new DisplayMetrics();
        //取得窗口属性
        getDisplay().getRealMetrics(dm);

        //窗口的宽度
        screenWidth= dm.widthPixels;
        //窗口高度
        screenHeight = dm.heightPixels;
        Log.i(TAG, "screenWidth : " + screenWidth + " screenHeight : " + screenHeight);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    class ClientThread implements Runnable {
        int PORT=8888;
        private Handler handler;   // 这个就是用于发送到UI，构造的时候吧上面类里定义的属性传进来

        public ClientThread(Handler handler) {
            this.handler = handler;
        }

        @Override
        public void run() {
            socket = new Socket();
            try {
                socket.connect(new InetSocketAddress("10.0.2.2",PORT), 5000);
                writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8)), true);
                reader = new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.UTF_8));

                // 创建启动子线程，接受服务端消息
                new Thread(()->{
                    String msg;
                    while (true) {
                        try {
                            if (!((msg= reader.readLine()) != null)) break;
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                        Log.e(TAG, "get from server:" + msg);
                        Message msgFromServer = new Message();
                        msgFromServer.what = 2;
                        msgFromServer.obj = msg;
                        handler.sendMessage(msgFromServer);
                    }
                }).start();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    // 这个是在Basegame里面绘制的时候使用
    public static int getOpponentScore() {
        return opponentScore;
    }
}