package com.example.aircraftwar2024.music;

import android.content.Context;
import android.media.MediaPlayer;

import com.example.aircraftwar2024.R;

public class MyMediaPlayer {

    private MediaPlayer bgm;
    private MediaPlayer boss_bgm;
    int position;

    public boolean isplayingBossBgm = false;
    private boolean musicSwitch;
    public MyMediaPlayer(Context context, boolean musicSwitch) {

        this. musicSwitch = musicSwitch;
        if(musicSwitch) {
            bgm = MediaPlayer.create(context, R.raw.bgm);
            boss_bgm = MediaPlayer.create(context, R.raw.bgm_boss);
            bgm.setLooping(true);
            boss_bgm.setLooping(true);
        }
    }

    public void startBgm() {
        if (musicSwitch){
            bgm.start();
        }

    }
    public void goOnBgm() {
        if(musicSwitch){
            position = bgm.getCurrentPosition();
            bgm.seekTo(position);
            bgm.start();
        }

    }
    public void pauseBgm() {
        if(musicSwitch){
            bgm.pause();
        }

    }
    public void startBossBgm(){
        if(musicSwitch){
            boss_bgm.start();
            isplayingBossBgm = true;
        }

    }
    public void pauseBossBgm() {
        if(musicSwitch){
            boss_bgm.pause();
            isplayingBossBgm = false;
        }

    }
    public void endAllBgm(){
        if(musicSwitch){
            bgm.stop();
            bgm.release();
            bgm = null;
            boss_bgm.stop();
            boss_bgm.release();
            boss_bgm = null;
        }

    }

}
