package com.example.aircraftwar2024.activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.example.aircraftwar2024.Dao.PlayerRecord;
import com.example.aircraftwar2024.Dao.PlayerRecordDao;
import com.example.aircraftwar2024.Dao.PlayerRecordDaoImpl;
import com.example.aircraftwar2024.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RecordActivity extends AppCompatActivity {

    private int gameType;

    public PlayerRecord playerRecord;
    public PlayerRecordDao playerRecordDao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ActivityManager.getActivityManager().finishActivity();
        ActivityManager.getActivityManager().addActivity(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);
        if(getIntent() != null){
            gameType = getIntent().getIntExtra("gameType",1);
        }
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView textView = findViewById(R.id.difficulty);





        // 创建dao对象
        if(gameType == 1) {
            playerRecordDao = new PlayerRecordDaoImpl("Easy",this);
            textView.setText("简单模式");
        } else if (gameType == 2) {
            playerRecordDao = new PlayerRecordDaoImpl("Normal",this);
            textView.setText("一般模式");
        } else {
            playerRecordDao = new PlayerRecordDaoImpl("Hard",this);
            textView.setText("困难模式");
        }

        // 创建单条记录对象， 从GameActivity获取到本次的分数，用于构建对象
        int score = getIntent().getIntExtra("score",1);
        playerRecord = new PlayerRecord("test", score );

        // 加入
        playerRecordDao.addRecord(playerRecord);
        playerRecordDao.saveRecords();

        showRankList();

        Button button = findViewById(R.id.return_btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent intent = new Intent(RecordActivity.this, MainActivity.class);
//                startActivity(intent);
                ActivityManager.getActivityManager().finishActivity();
                // 除了offlineActivity，此前每次进入一个新的activity，就会结束上一个，因此到这里的时候，只有MainActivity和RecordActivity是在的，结束掉RecordActivity，自然就到了MainActivity。

            }
        });
    }



    public void showRankList() {

        ListView listView = findViewById(R.id.list);
        List<Map<String,String>> maps = new ArrayList<>();
        List<PlayerRecord> records = playerRecordDao.getAllRecords();

        String[] coulumns = new String[]{"rank", "name", "score", "time"};

        for (int i = 0; i < records.size(); i++) {
            Map<String,String> record = new HashMap<>();
            record.put("rank", String.valueOf(records.get(i).getRank()));
            record.put("name", records.get(i).getUserName());
            record.put("score", String.valueOf(records.get(i).getScore()));
            record.put("time", records.get(i).getLocalDateTime());
            maps.add(record);
        }
          // activity_item样式决定了数据显示的字体等  2024/6/4 15:18 修改了样式，调小了时间的字号
        SimpleAdapter adapter = new SimpleAdapter(this, maps, R.layout.activity_item, coulumns, new int[]{R.id.rank,R.id.name,R.id.score,R.id.time});

        listView.setAdapter(adapter);


        // 实现点击删除功能

        listView.setOnItemClickListener( new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long l) {
                AlertDialog alertDialog = new AlertDialog.Builder(RecordActivity.this)
                        .setTitle("提示")
                        .setMessage("确定删除该条记录")
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
//                                maps.remove(position);    map直接重建，因为更新视图主要是看这一个map，只能把这map对象清空，然后重新装载一遍
//                                records.remove(position);
                                playerRecordDao.deleteRecord(position);

                                maps.clear();

                                for (int j= 0; j < records.size(); j++) {
                                    Map<String,String> record = new HashMap<>();
                                    record.put("rank", String.valueOf(records.get(j).getRank()));
                                    record.put("name", records.get(j).getUserName());
                                    record.put("score", String.valueOf(records.get(j).getScore()));
                                    record.put("time", records.get(j).getLocalDateTime());
                                    maps.add(record);
                                }
                                adapter.notifyDataSetChanged();


                            }
                        })
                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        })
                        .create();
                alertDialog.show();
            }


        });

    }


}