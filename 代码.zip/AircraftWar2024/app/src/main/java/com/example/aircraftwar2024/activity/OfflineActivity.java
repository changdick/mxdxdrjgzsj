package com.example.aircraftwar2024.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import com.example.aircraftwar2024.R;

public class OfflineActivity extends AppCompatActivity {
    private Button btn_easy;
    private Button btn_normal;
    private Button btn_hard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ActivityManager.getActivityManager().addActivity(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offline);
        boolean musicSwitch = getIntent().getBooleanExtra("musicSwitch",true);

//        // 下面两句只是测试一下传递参数是否成功，xml里面的textView2控件也是不需要的。
//        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView textView = findViewById(R.id.textView2);
//        textView.setText(str);

        // 通过id获取三个选择难度的按钮
        btn_easy = findViewById(R.id.buttonEasy);
        btn_normal = findViewById(R.id.buttonNormal);
        btn_hard = findViewById(R.id.buttonHard);
        // 分别给三个Button绑定监听到的方法，要做一个界面的跳转，从该界面跳转到GameActivity，要用Intent注册页面跳转，并且传一个"gameType"的值
        Intent intent = new Intent(OfflineActivity.this, GameActivity.class);
        intent.putExtra("musicSwitch", musicSwitch);
        btn_easy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent.putExtra("gameType", 1);
                startActivity(intent);
            }
        });

        btn_normal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent.putExtra("gameType", 2);
                startActivity(intent);
            }
        });

        btn_hard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent.putExtra("gameType", 3);
                startActivity(intent);
            }
        });
    }
}