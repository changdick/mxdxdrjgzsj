package com.example.aircraftwar2024.Dao;

import android.app.Activity;
import android.content.Context;

import java.io.*;
import java.util.*;

public class PlayerRecordDaoImpl implements PlayerRecordDao{
    private String FILENAME;
    private List<PlayerRecord> records;
    private Context context;

    Comparator<PlayerRecord> compareScore = (o1, o2) -> Integer.compare(o2.getScore(), o1.getScore());

    public PlayerRecordDaoImpl(String difficulty,Context context){
        this.context = context;
        FILENAME = "RecordRankBoard"+difficulty+".txt";

         records = new ArrayList<>();

        try (ObjectInputStream inputStream = new ObjectInputStream(context.openFileInput(FILENAME))) {
            records = (List<PlayerRecord>) inputStream.readObject();
            System.out.println("排行榜加载成功！");
        } catch (FileNotFoundException e) {
            System.out.println("找不到保存的排行榜文件：" + e.getMessage());
        } catch (IOException e) {
            System.out.println("加载排行榜时出错：" + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("无法解析保存的排行榜文件：" + e.getMessage());
        }
    }
    @Override
    public List<PlayerRecord> getAllRecords(){
        return records;
    }

    @Override
    public void addRecord(PlayerRecord record) {
        records.add(record);
        rankRecords();
    }

    @Override
    public void saveRecords() {

        try (ObjectOutputStream outputStream = new ObjectOutputStream(context.openFileOutput(FILENAME, Context.MODE_PRIVATE))) {
            outputStream.writeObject(records);
            outputStream.close();
            System.out.println("排行榜保存成功！");
        } catch (IOException e) {
            System.out.println("保存排行榜时出错：" + e.getMessage());
        }
    }

    private void rankRecords() {
        records.sort(compareScore);
        for (int i = 0; i < records.size(); i++) {
            records.get(i).setRank(i+1);
        }
    }

    @Override
    public void deleteRecord(int index) {
        records.remove(records.get(index));
        rankRecords();
        saveRecords();
    }
}
