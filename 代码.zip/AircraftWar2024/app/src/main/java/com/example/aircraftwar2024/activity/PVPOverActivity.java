package com.example.aircraftwar2024.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.aircraftwar2024.R;

public class PVPOverActivity extends AppCompatActivity {
    private static final String TAG = "PVPOverActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ActivityManager.getActivityManager().finishActivity(); // 销毁上一个活动，那么会结束PVPActivity

        Log.i(TAG, "jump to pvpoveractivity");
        ActivityManager.getActivityManager().addActivity(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pvpover);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView textViewYourScore = findViewById(R.id.yourscoreOver);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView textViewOppoScore = findViewById(R.id.oppoScoreOver);
        int score = getIntent().getIntExtra("yourScore",0);
        int oppoScore = getIntent().getIntExtra("oppoScore", 0);
        textViewYourScore.setText(String.valueOf(score));
        textViewOppoScore.setText(String.valueOf(oppoScore));


        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button button = findViewById(R.id.buttonReturn_inOver);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityManager.getActivityManager().finishActivity();
            }
        });
    }
}