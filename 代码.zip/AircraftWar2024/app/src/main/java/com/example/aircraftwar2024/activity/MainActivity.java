package com.example.aircraftwar2024.activity;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.aircraftwar2024.R;

// 2024/6/19 更新了结束界面背景， 删去一些弃用代码，mainactivity中的弃用的代码全删了
/**
 * 220110430
 * MainActivity 设置界面为对应的xml，对其中的三个控件：单击按钮，联机按钮两个Button和选择音效开关的 RadioGroup 全都要获取，两个按钮都进行监听。如果有点击，直接Intent跳转到目标的activity
 * 在跳转前，获取到RadioGroup中被选中的RadioButton，判断它上面的text内容设置好musicOn的值，供后面basegame调用。之后直接跳转。
 */

public class MainActivity extends AppCompatActivity {
    private Button btn1;
    private Button pvpBtn;
    /**
     *  设置音乐播放
     *  musicGP是音乐选择控件
     *  musicSwitch 实验2时创建 原本方案是先获取对应的字符串，传向OfflineActivity，再传到GameActivity， GameActivity里面的boolean量供给Basegame中创建音乐播放对象时使用，以指定音乐是否播放
     *  musicOn 实验6最终创建 设置为公开，原本方案不使用也不删去，直接增加musicOn，用于Basegame中调用，不必区分单机联机
     *
     */
    private RadioGroup musicGP;
    private String musicSwitch;
    public static boolean musicOn;   // 直接把musicSwitch开关放置在MainActivity中设置为公开， 不再使用intent往后面传递获取。不论是联机还是单机，Basegame都可以直接在创建两种音乐播放对象的时候直接调用这一个musicSwitch，我们把它改成boolean型
    public static String game_mode;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ActivityManager.getActivityManager().addActivity(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 获取startGameButton过来，对他做一个监听
        btn1 = findViewById(R.id.statGameButton);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                game_mode = "pve";
                Intent intent = new Intent(MainActivity.this, OfflineActivity.class);
                // 获取musicSwitch的radiogroup进行监听
                musicGP = findViewById(R.id.musicSwich);
                // 用musicGP的方法获取它被选中的radioButton的id，找到那个Button
                RadioButton checked = (RadioButton) findViewById(musicGP.getCheckedRadioButtonId());
                // 直接获得那个button的text内容
                musicSwitch = checked.getText().toString();
                if (musicSwitch.equalsIgnoreCase("开启音乐")){
                    intent.putExtra("musicSwitch", true);
                    musicOn = true;
                }  else if (musicSwitch.equalsIgnoreCase("关闭音乐")) {
                    intent.putExtra("musicSwitch", false);
                    musicOn = false;
                }
                startActivity(intent);
            }
        });
        pvpBtn = findViewById(R.id.PVPButton);
        pvpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                game_mode = "pvp";
                // 获取musicSwitch的radiogroup进行监听
                musicGP = findViewById(R.id.musicSwich);
                // 用musicGP的方法获取它被选中的radioButton的id，找到那个Button
                RadioButton checked = (RadioButton) findViewById(musicGP.getCheckedRadioButtonId());
                // 直接获得那个button的text内容
                musicSwitch = checked.getText().toString();
                if (musicSwitch.equalsIgnoreCase("开启音乐")){
                    musicOn = true;
                }  else if (musicSwitch.equalsIgnoreCase("关闭音乐")) {
                    musicOn = false;
                }
                Intent intent = new Intent(MainActivity.this, PVPActivity.class);
                startActivity(intent);
            }
        });
    }
}

