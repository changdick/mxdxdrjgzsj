package com.example.lib;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyClass {
    public static void main(String[] args) throws IOException {
        new MyClass();
    }

    /**
     * playerList Socket类的列表， serverSocket连接上客户端后返回的socket，加入到该列表中
     */
    public static List<Socket> playerList = new ArrayList<>();
    public MyClass() throws IOException {
        int port = 8888;
        ServerSocket serverSocket = new ServerSocket(port);
        System.out.println(InetAddress.getLocalHost());
        new Thread(()->{
            try {
                acceptConnection(serverSocket);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }).start();
    }
    private void acceptConnection(ServerSocket serverSocket) throws IOException {
        while(true) {
            System.out.println("---waiting for connect---");
            Socket socket1 = serverSocket.accept();
            Socket socket2 = serverSocket.accept();
            playerList.add(socket1);
            System.out.println("player connected: " + playerList.size());
            playerList.add(socket2);
            System.out.println("player connected: " + playerList.size());
            // 开启线程，通过socket与客户端连接
            new Thread(new ServerSocketThread(socket1, socket2)).start();
            new Thread(new ServerSocketThread(socket2, socket1)).start();
        }
    }
}