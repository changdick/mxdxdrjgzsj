package com.example.lib;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Map;

/**
 * 处理与客户端的连接的线程
 * 与两个客户端连接成功后，会启动两个这样的线程
 * 该线程需要与两个客户端的连接的socket都要读入，这个线程是负责：1.判断游戏开始，通知A开始游戏，2.接收A的信息,其中分数信息发往B。3.判断游戏结束，通知双方游戏结束
 */
public class ServerSocketThread extends Thread{
    private BufferedReader in;
    private PrintWriter pw;
    private Socket socket;
    private PrintWriter oppoWriter;
    Socket oppoSocket;
    public ServerSocketThread(Socket socket, Socket oppoSocket) throws IOException {
        this.socket = socket;
        this.oppoSocket = oppoSocket;

        in = new BufferedReader(new InputStreamReader(socket.getInputStream(),"UTF-8"));
        pw = new PrintWriter(new BufferedWriter(
                new OutputStreamWriter(socket.getOutputStream(), "UTF-8")), true);

        oppoWriter= new PrintWriter(new BufferedWriter(
                new OutputStreamWriter(oppoSocket.getOutputStream(), "UTF-8")), true);

    }

    @Override
    public void run(){
        try {

            // 当两个玩家，服务器主动发送开始信号
            if(MyClass.playerList.size()==2) {
                sentData("start");
            }
            String content;
            while ((content = in.readLine()) != null) {
                //4.和客户端通信
                // 接收到的content是分数或者end
                if (content.equals("end")) {
                    MyClass.playerList.remove(socket);
                    System.out.println("player alive: " + MyClass.playerList.size());
                    if (MyClass.playerList.size() == 0) {
                        break;
                    }
                } else {
                    // 进入这个块肯定是收到分数，直接往对手那边发
                    oppoWriter.println(content);
                }
            }
            // 如果上面while块结束，也没有人了，那就发送结束信号
            if (MyClass.playerList.size() == 0) {
                sentData("gameover");
                oppoWriter.println("gameover");
                System.out.println("gameover");
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void sentData(String data) throws IOException {
        pw.println(data);
    }
}
